import java.lang.*;
import EntityList.*;
import Entity.*;
import Interfaces.*;
import File.*;

import GUI.*;
public class start{
	public static void main(String [] args){
				
	  Welcome w = new Welcome();
		w.setVisible(true);
		
		         }}